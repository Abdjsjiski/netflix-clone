# Netflix Clone
This Project is a Training Project TO Create , Apply Some SASS Styles, Techniques , with React.js Operaions Such As Dialogs, StateFul, Stateless Componenets, Props , Etc

# Libraries
1. React.js
2. React Router
3. Material UI
4. Google Fonts

![New Project (2)](https://user-images.githubusercontent.com/29167110/94851433-4e39d200-03dd-11eb-80af-bd7c2efcf2ff.jpg)

![New Project (3)](https://user-images.githubusercontent.com/29167110/94851430-4da13b80-03dd-11eb-9ab8-0a3f58583781.jpg)

![New Project (4)](https://user-images.githubusercontent.com/29167110/94851428-4c700e80-03dd-11eb-8f30-b02b605c7a06.jpg)

![New Project (1)](https://user-images.githubusercontent.com/29167110/94851435-4ed26880-03dd-11eb-8680-aaed2e9f2efb.png)
